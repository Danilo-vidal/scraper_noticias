# Scraper Notícias G1

Este projeto realiza web scraping no site do G1 e exibe os 10 primeiros títulos de notícias.