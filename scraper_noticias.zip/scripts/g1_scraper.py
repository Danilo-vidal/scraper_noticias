import requests
from bs4 import BeautifulSoup

def buscar_titulos():
    url = "https://g1.globo.com/"
    resposta = requests.get(url)

    if resposta.status_code == 200:
        soup = BeautifulSoup(resposta.text, 'html.parser')
        titulos = soup.find_all('a', class_='feed-post-link')

        print("🔎 Últimas notícias do G1:\n")
        for i, titulo in enumerate(titulos[:10]):
            print(f"{i+1}. {titulo.text.strip()}")
    else:
        print("Erro ao acessar o site.")

if __name__ == "__main__":
    buscar_titulos()
